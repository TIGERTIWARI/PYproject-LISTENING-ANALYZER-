from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import matplotlib
# Use 'Agg' backend so Matplotlib generates images silently for the web instead of opening a window
matplotlib.use('Agg') 
import matplotlib.pyplot as plt #for creating and customizing graphs
import seaborn as sns #It makes statistical graphs easier and more attractive.
import os
import time 
app = Flask(__name__) #Flask creates the web application.
# app is the application object.
# __name__ tells Flask where the application is located.
# Ensure the static folder exists to save the plot
os.makedirs(app.static_folder, exist_ok=True)
# Route 1: Load the homepage
@app.route('/') #It tells Flask which URL should execute the function
def home():
    return render_template('project1.html')
# Route 2: Handle the button click and run the analysis
# Route 2: Handle the file upload with Error Handling & Data Cleaning
@app.route('/analyze', methods=['POST']) #It creates a route called /analyze.
# POST is an HTTP method used to send data from the browser to the server.
def analyze():
    try:
        uploaded_file = request.files['dataset']
        # request receives information from the browser.
# files contains uploaded files.
# 'dataset' is the name of the HTML file input.
# uploaded_file stores the uploaded file object.
        if uploaded_file.filename == '':
            return "<h2 style='color: white; text-align: center; font-family: sans-serif;'>Error: No file selected. Go back and try again.</h2>"

        # 1. Read Data 
        df = pd.read_csv(uploaded_file)
        
        # --- FIX 1: Robust Column Header Detection (Ignores Case) ---
        # Make all column headers lowercase and remove extra spaces
        df.columns = df.columns.str.strip().str.lower() #Returns all column names from the DataFrame
        # Look for the required columns flexibly
        day_col = next((c for c in df.columns if 'day' in c), None)
        genre_col = next((c for c in df.columns if 'genre' in c), None)
        min_col = next((c for c in df.columns if 'min' in c or 'time' in c or 'listen' in c), None)
        
        if not (day_col and genre_col and min_col):
            return "<h2 style='color: white; text-align: center; font-family: sans-serif;'>Format Error!</h2><p style='color: white; text-align: center; font-family: sans-serif;'>Your file is missing required columns (Day, Genre, Minutes). Please check the Format Guide.</p>"
            
        # Rename them to the exact names our code expects
        df = df.rename(columns={day_col: 'Day', genre_col: 'Genre', min_col: 'Minutes_Listened'})
        
        # --- FIX 2: Data Cleaning (Fixes Case Sensitivity & Spaces) ---
        # Converts "pop", "POP", and " pop " all into "Pop"
        df['Genre'] = df['Genre'].astype(str).str.strip().str.title()
        # Converts "monday", "mOnday" all into "Monday"
        df['Day'] = df['Day'].astype(str).str.strip().str.title()

        # Clean Minutes (Force to numbers, ignoring text)
        df['Minutes_Listened'] = pd.to_numeric(df['Minutes_Listened'], errors='coerce')
        df = df.dropna(subset=['Minutes_Listened', 'Genre', 'Day']) 
        df = df[df['Minutes_Listened'] > 0]
        
        if df.empty:
            return "<h2 style='color: white; text-align: center; font-family: sans-serif;'>Data Error!</h2><p style='color: white; text-align: center; font-family: sans-serif;'>No valid listening data found. Make sure minutes are numbers greater than 0.</p>"
        
        genre_totals = df.groupby('Genre')['Minutes_Listened'].sum().reset_index()

        # 2. Mathematical Statistics (NumPy)
        minutes_array = np.array(df['Minutes_Listened'])
        total_time = int(np.sum(minutes_array))
        avg_time = float(np.mean(minutes_array))
        
        # 3. Logic (Standard Python)
        if avg_time > 60:
            profile = "Heavy Listener"
        elif avg_time > 30:
            profile = "Casual Listener"
        else:
            profile = "Light Listener"

        stats_data = {
            "total_time": total_time,
            "avg_time": round(avg_time, 2),
            "profile": profile
        }

        # 4. Generate Visualization (Matplotlib & Seaborn)
        plt.rcParams['text.color'] = 'white'
        plt.rcParams['axes.labelcolor'] = 'white'
        plt.rcParams['xtick.color'] = 'white'
        plt.rcParams['ytick.color'] = 'white'

        plt.figure(figsize=(10, 5))
        
        # Bar Chart
        plt.subplot(1, 2, 1)
        sns.barplot(data=genre_totals, x='Genre', y='Minutes_Listened', palette="mako")
        plt.title("Total Minutes by Genre")
        plt.xticks(rotation=45)

        # Heatmap
        plt.subplot(1, 2, 2)
        heatmap_data = df.pivot_table(index='Day', columns='Genre', values='Minutes_Listened', aggfunc='sum', fill_value=0)
        
        # Reorder days chronologically if they exist in the uploaded file
        days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        existing_days = [day for day in days_order if day in heatmap_data.index]
        if existing_days:
            heatmap_data = heatmap_data.reindex(existing_days)

        sns.heatmap(heatmap_data, cmap="rocket", annot=True, fmt=".0f", cbar=False)
        #heatmap_data	Provides the table to visualize.
# cmap="rocket"	Sets the color scheme.
# annot=True	Displays numerical values inside cells.
# fmt=".0f"	Displays values without decimal places.
# cbar=False	Hides the color bar.
        plt.title("Day vs Genre")
        plt.xticks(rotation=45)
        plt.tight_layout()
        
        plot_path = os.path.join(app.static_folder, 'plot.png')
        plt.savefig(plot_path, transparent=True) 
        plt.close() 
        timestamp = int(time.time())
        return render_template('project1.html', stats=stats_data, timestamp=timestamp)    
    except Exception as e:
        return f"<h2 style='color: white; text-align: center; font-family: sans-serif;'>Oops! Something went wrong.</h2><p style='color: white; text-align: center; font-family: sans-serif;'><i>Developer Error Code: {str(e)}</i></p>"
if __name__ == '__main__':
    app.run(debug=True)







































# BELOW CODE FOR FAKE DATA CREATION WITHOUT USERINPUT AND WEB PROGRAMMING 
# import csv
# import random
# UNIT 1: Functions, variables, and control flow
# def generate_mock_data(filename):
#     genres = ["Pop", "Rock", "Hip-Hop", "Classical", "Jazz", "Electronic"]
#     days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

#     # UNIT 2: Basic file handling (write CSV), lists, and tuples
#     with open(filename, mode='w', newline='') as file:
#         writer = csv.writer(file)
#         writer.writerow(["Day", "Genre", "Minutes_Listened", "Track_ID"]) # Header
        
#         # UNIT 1: Loops
#         for i in range(200):
#             day = random.choice(days)
#             genre = random.choice(genres)
#             # Introducing some dirty data (0 minutes) to clean later
#             minutes = random.choice([0, 15, 30, 45, 60, 120, None]) 
#             track_id = f"TRK-{i+1000}" # UNIT 2: String manipulation
#             writer.writerow([day, genre, minutes, track_id])
# generate_mock_data("listening_history.csv")
# import pandas as pd

# # UNIT 4: Reading data from CSV files, Series and DataFrame creation
# df = pd.read_csv("listening_history.csv")

# # UNIT 4: Data cleaning (handling missing values, dropping columns)
# # Drop rows where 'Minutes_Listened' is missing (NaN)
# df = df.dropna(subset=['Minutes_Listened']) 
# # Drop Track_ID as we don't need it for broad analysis
# df = df.drop(columns=['Track_ID']) 

# # Remove entries where minutes are 0 (bad data)
# df = df[df['Minutes_Listened'] > 0]

# # UNIT 4: Data aggregation and grouping
# # Total minutes spent on each genre
# genre_totals = df.groupby('Genre')['Minutes_Listened'].sum().reset_index()
# print("\n--- Total Listening Time by Genre ---")
# print(genre_totals)


# import numpy as np

# # UNIT 3: Arrays, indexing, slicing, mathematical and statistical operations
# # Convert the Pandas column directly into a NumPy array
# minutes_array = np.array(df['Minutes_Listened'])

# # Calculate statistics
# average_time = np.mean(minutes_array)
# max_session = np.max(minutes_array)
# total_time = np.sum(minutes_array)

# print("\n--- Listening Statistics (NumPy) ---")
# print(f"Total Minutes Listened: {total_time}")
# print(f"Average Session Duration: {average_time:.2f} mins")
# print(f"Longest Single Session: {max_session} mins")


# # UNIT 1: Functions, if-else, typecasting
# def categorize_listener(avg_minutes):
#     if float(avg_minutes) > 45:
#         return "Heavy Listener"
#     elif float(avg_minutes) > 20:
#         return "Casual Listener"
#     else:
#         return "Light Listener"

# listener_profile = categorize_listener(average_time)
# print(f"\nUser Profile based on average: {listener_profile}")

# # UNIT 2: List comprehensions & Dictionaries
# # Create a dictionary of genres mapped to their lengths using comprehension
# unique_genres = df['Genre'].unique()
# genre_lengths = {genre: len(genre) for genre in unique_genres}


# import matplotlib.pyplot as plt
# import seaborn as sns

# # UNIT 5: Customization of plots (titles, labels)
# sns.set_theme(style="whitegrid")
# plt.figure(figsize=(12, 5))

# # Plot 1: Bar Chart of Total Time by Genre (Matplotlib/Seaborn)
# # UNIT 5: Bar plots
# plt.subplot(1, 2, 1)
# sns.barplot(data=genre_totals, x='Genre', y='Minutes_Listened', palette="viridis")
# plt.title("Total Minutes by Genre")
# plt.xlabel("Music Genre")
# plt.ylabel("Minutes Listened")
# plt.xticks(rotation=45)

# # Plot 2: Heatmap of Listening Habits by Day (Seaborn)
# # UNIT 5: Heatmaps
# plt.subplot(1, 2, 2)
# # Create a pivot table for the heatmap
# heatmap_data = df.pivot_table(index='Day', columns='Genre', values='Minutes_Listened', aggfunc='sum', fill_value=0)
# # Reorder days for chronological sense
# days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
# heatmap_data = heatmap_data.reindex(days_order)

# sns.heatmap(heatmap_data, cmap="YlGnBu", annot=True, fmt=".0f")
# plt.title("Listening Intensity: Day vs Genre")

# plt.tight_layout()
# plt.show()